PO Auto Signals — V2 (اختبار أولي)

الملفات:
- index.html: واجهة عربية RTL وتحليل فني أولي.
- sw.js: Service Worker للتخزين المؤقت.
- manifest.webmanifest: بيانات تثبيت PWA.

الأصول الافتراضية: XAUUSD وEURUSD وGBPUSD وUSDJPY وAUDUSD وUS30 وNAS100 وSPX500 وDAX40.
مصدر الأسعار الافتراضي: Biquote REST GET https://biquote.io/api/latest مع تكرار معامل symbols لكل أصل.

ضوابط البيانات:
- لا يقبل التطبيق إلا marketState=open.
- يرفض stale=true أو timestamp غير صالح أو اقتباساً عمره أكثر من 60 ثانية.
- يحسب السعر من mid أو من متوسط bid/ask.
- يحدّث الطلب المجمع كل 5 ثوانٍ. راجع حالة كل رمز في الواجهة؛ قد لا تكون جميع أسماء المؤشرات مدعومة لدى المزوّد.

حدود مهمة:
- هذا محلل إشارات فقط؛ لا يتصل بحساب Pocket Option ولا ينفّذ صفقات.
- أسعار Biquote ليست بالضرورة أسعار Pocket Option، وقد تختلف خصوصاً في OTC.
- التحليل الحالي يستخدم تسلسل الأسعار المستلمة ولا يستخدم شموع OHLC متعددة الأطر. لا تعتبر درجة التوافق احتمال نجاح أو توصية مالية.
- اختبر على حساب تجريبي فقط، وقارن السعر والوقت مع المنصة قبل أي استخدام.
- لا تدخل كلمة مرور أو بيانات دخول أو مفاتيح حساب Pocket Option.

التثبيت على iPhone: فعّل GitHub Pages من Settings > Pages واختر Deploy from a branch ثم main / root. بعد نشر HTTPS افتح رابط Pages في Safari > مشاركة > إضافة إلى الشاشة الرئيسية.
